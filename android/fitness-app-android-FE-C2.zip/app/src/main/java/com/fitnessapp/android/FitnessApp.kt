package com.fitnessapp.android

import android.app.Application
import com.fitnessapp.android.data.HealthConnectRepository
import com.fitnessapp.android.data.cache.DailySummaryCache
import com.fitnessapp.android.data.cache.PrefsDailySummaryCache
import com.fitnessapp.android.data.network.ApiClient
import com.fitnessapp.android.data.network.AuthStore
import com.fitnessapp.android.data.sync.SyncScheduler

/** Manual DI container — kept small and explicit for a v1 shell. */
class AppContainer(context: android.content.Context) {
    val authStore: AuthStore = AuthStore(context)
    val healthRepository: HealthConnectRepository = HealthConnectRepository(context)
    val dailyCache: DailySummaryCache =
        PrefsDailySummaryCache(context.getSharedPreferences("fitness_app_daily_cache", android.content.Context.MODE_PRIVATE))
    val apiClient: ApiClient = ApiClient { authStore.baseUrl }
    val syncScheduler: SyncScheduler = SyncScheduler
}

class FitnessApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        // Periodic WorkManager sync survives reboots; schedule once per process.
        SyncScheduler.schedulePeriodic(this)
    }
}
