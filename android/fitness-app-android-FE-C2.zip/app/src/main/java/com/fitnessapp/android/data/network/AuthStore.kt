package com.fitnessapp.android.data.network

import android.content.Context
import android.content.SharedPreferences

/** Durable app settings + JWT session. v1 stores the token in private prefs. */
class AuthStore(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("fitness_app_auth", Context.MODE_PRIVATE)

    var jwt: String?
        get() = prefs.getString(KEY_JWT, null)
        set(value) = prefs.edit().putString(KEY_JWT, value).apply()

    var email: String?
        get() = prefs.getString(KEY_EMAIL, null)
        set(value) = prefs.edit().putString(KEY_EMAIL, value).apply()

    /** Backend base URL including /api/v1. Emulator reaches the host via 10.0.2.2. */
    var baseUrl: String
        get() = prefs.getString(KEY_BASE_URL, DEFAULT_BASE_URL) ?: DEFAULT_BASE_URL
        set(value) = prefs.edit().putString(KEY_BASE_URL, value.trimEnd('/')).apply()

    fun recordSyncSuccess(date: String, atMillis: Long = System.currentTimeMillis()) {
        prefs.edit()
            .putString(KEY_LAST_SYNC_DATE, date)
            .putLong(KEY_LAST_SYNC_AT, atMillis)
            .putString(KEY_LAST_SYNC_STATUS, "ok")
            .apply()
    }

    fun recordSyncError(message: String) {
        prefs.edit().putString(KEY_LAST_SYNC_STATUS, message.take(200)).apply()
    }

    fun lastSync(): Pair<String?, Long> = prefs.getString(KEY_LAST_SYNC_DATE, null) to prefs.getLong(KEY_LAST_SYNC_AT, 0L)

    fun lastSyncStatus(): String? = prefs.getString(KEY_LAST_SYNC_STATUS, null)

    fun clearSession() {
        prefs.edit()
            .remove(KEY_JWT)
            .remove(KEY_EMAIL)
            .apply()
    }

    companion object {
        const val DEFAULT_BASE_URL = "http://10.0.2.2:8000/api/v1"
        private const val KEY_JWT = "jwt"
        private const val KEY_EMAIL = "email"
        private const val KEY_BASE_URL = "base_url"
        private const val KEY_LAST_SYNC_DATE = "last_sync_date"
        private const val KEY_LAST_SYNC_AT = "last_sync_at"
        private const val KEY_LAST_SYNC_STATUS = "last_sync_status"
    }
}
