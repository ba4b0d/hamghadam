package com.fitnessapp.android.data.network

import com.fitnessapp.android.data.model.DailySummary
import com.fitnessapp.android.data.model.DailySummaryCodec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

sealed class ApiResult<out T> {
    data class Success<T>(val value: T, val httpCode: Int) : ApiResult<T>()
    data class Unauthorized(val detail: String) : ApiResult<Nothing>()
    data class Conflict(val detail: String) : ApiResult<Nothing>()
    data class Validation(val detail: String) : ApiResult<Nothing>()
    data class Failure(val detail: String) : ApiResult<Nothing>()
}

data class AuthSession(val token: String, val expiresIn: Int)

/** Thin OkHttp client for the BE-C1 API (register/login/daily ingest). */
class ApiClient(private val baseUrlProvider: () -> String) {

    private val jsonMedia = "application/json; charset=utf-8".toMediaType()
    private val ok = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private fun base() = baseUrlProvider().trimEnd('/')

    suspend fun register(email: String, password: String, displayName: String? = null, tzOffset: Int? = null): ApiResult<AuthSession> =
        withContext(Dispatchers.IO) {
            val body = JSONObject().apply {
                put("email", email)
                put("password", password)
                displayName?.let { put("display_name", it) }
                tzOffset?.let { put("tz_offset", it) }
            }
            val request = Request.Builder()
                .url("${base()}/auth/register")
                .post(body.toString().toRequestBody(jsonMedia))
                .build()
            executeAuth(request)
        }

    suspend fun login(email: String, password: String): ApiResult<AuthSession> =
        withContext(Dispatchers.IO) {
            val body = JSONObject()
                .put("email", email)
                .put("password", password)
            val request = Request.Builder()
                .url("${base()}/auth/login")
                .post(body.toString().toRequestBody(jsonMedia))
                .build()
            executeAuth(request)
        }

    suspend fun postDaily(token: String, summary: DailySummary): ApiResult<Unit> =
        withContext(Dispatchers.IO) {
            val body = JSONObject(summary.toPayloadMap())
            val request = Request.Builder()
                .url("${base()}/daily")
                .addHeader("Authorization", "Bearer $token")
                .post(body.toString().toRequestBody(jsonMedia))
                .build()
            try {
                ok.newCall(request).execute().use { resp ->
                    val text = resp.body?.string().orEmpty()
                    when (resp.code) {
                        in 200..299 -> ApiResult.Success(Unit, resp.code)
                        401 -> ApiResult.Unauthorized(parseDetail(text) ?: "Unauthorized")
                        422 -> ApiResult.Validation(parseDetail(text) ?: "Validation error")
                        else -> ApiResult.Failure("HTTP ${resp.code}: ${text.take(200)}")
                    }
                }
            } catch (e: IOException) {
                ApiResult.Failure(e.message ?: "Network error")
            }
        }

    /**
     * BE-C1 GET /api/v1/daily?date=YYYY-MM-DD — read back one day's row.
     * Returns Failure("HTTP 404 …") when the server has no row for that date.
     */
    suspend fun getDaily(token: String, date: String): ApiResult<DailySummary> =
        withContext(Dispatchers.IO) {
            val request = Request.Builder()
                .url("${base()}/daily?date=$date")
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()
            try {
                ok.newCall(request).execute().use { resp ->
                    val text = resp.body?.string().orEmpty()
                    when (resp.code) {
                        in 200..299 -> {
                            val summary = DailySummaryCodec.fromJson(JSONObject(text))
                            if (summary == null) ApiResult.Failure("Unreadable daily row") else ApiResult.Success(summary, resp.code)
                        }
                        401 -> ApiResult.Unauthorized(parseDetail(text) ?: "Unauthorized")
                        404 -> ApiResult.Failure("HTTP 404: no row for $date")
                        else -> ApiResult.Failure("HTTP ${resp.code}: ${text.take(200)}")
                    }
                }
            } catch (e: IOException) {
                ApiResult.Failure(e.message ?: "Network error")
            }
        }

    /**
     * BE-C1 GET /api/v1/daily/range?from=YYYY-MM-DD&to=YYYY-MM-DD — rows for a
     * date window, oldest first. Missing days are simply absent from [List].
     */
    suspend fun getDailyRange(token: String, from: String, to: String): ApiResult<List<DailySummary>> =
        withContext(Dispatchers.IO) {
            val request = Request.Builder()
                .url("${base()}/daily/range?from=$from&to=$to")
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()
            try {
                ok.newCall(request).execute().use { resp ->
                    val text = resp.body?.string().orEmpty()
                    when (resp.code) {
                        in 200..299 -> {
                            val items = JSONObject(text).optJSONArray("items")
                            val rows = if (items == null) emptyList()
                            else (0 until items.length()).mapNotNull { DailySummaryCodec.fromJson(items.optJSONObject(it)) }
                            ApiResult.Success(rows, resp.code)
                        }
                        401 -> ApiResult.Unauthorized(parseDetail(text) ?: "Unauthorized")
                        404 -> ApiResult.Success(emptyList(), resp.code)
                        else -> ApiResult.Failure("HTTP ${resp.code}: ${text.take(200)}")
                    }
                }
            } catch (e: IOException) {
                ApiResult.Failure(e.message ?: "Network error")
            }
        }

    private fun executeAuth(request: Request): ApiResult<AuthSession> {
        return try {
            ok.newCall(request).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                when (resp.code) {
                    in 200..299 -> {
                        val json = JSONObject(text)
                        ApiResult.Success(
                            AuthSession(
                                token = json.getString("access_token"),
                                expiresIn = json.optInt("expires_in", 0),
                            ),
                            resp.code,
                        )
                    }
                    401 -> ApiResult.Unauthorized(parseDetail(text) ?: "Bad credentials")
                    409 -> ApiResult.Conflict(parseDetail(text) ?: "Email already registered")
                    422 -> ApiResult.Validation(parseDetail(text) ?: "Validation error")
                    else -> ApiResult.Failure("HTTP ${resp.code}: ${text.take(200)}")
                }
            }
        } catch (e: IOException) {
            ApiResult.Failure(e.message ?: "Network error")
        }
    }

    private fun parseDetail(text: String): String? =
        try {
            JSONObject(text).optString("detail").takeIf { it.isNotEmpty() }
        } catch (_: Exception) {
            null
        }
}
