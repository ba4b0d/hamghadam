# Fitness App — Android (FE-C1 + FE-C2)

Android shell for the all-in-one fitness app: reads daily health aggregates from
**Health Connect** (steps required; sleep + heart rate per permission), shows a
permission/connect UX, syncs a `DailySummary` to the backend
(**BE-C1** `/api/v1/daily`, JWT auth, idempotent upsert by user+date), and
renders the **FE-C2 dashboard**: today card with source attribution, a last-7-days
strip + steps bar chart (local cache → server range GET → Health Connect fallback),
and a "Connect your watch" Matchmaking CTA when nothing is connected yet.

- Kotlin + Jetpack Compose (Material 3), min SDK **28**, target/compile SDK **37**
- Health Connect Jetpack SDK **1.2.0-alpha05** (`androidx.health.connect:connect-client`)
  - read-only — **no writes to Health Connect** (v1)
  - per-type `READ_*` permissions via the Health Connect consent UI
  - **Matchmaking API** (`checkIfMatchmakingIsPossible` / `createMatchmakingIntent`)
    on the "Connect your watch" card for onboarding
  - background reads: `READ_HEALTH_DATA_IN_BACKGROUND` declared; the sync worker
    checks the grant and **falls back to foreground-only sync** when missing
- Daily sync: WorkManager periodic (24h + 6h flex) + one-shot "Sync now"
- Dashboard (FE-C2):
  - Today card: steps hero, sleep, avg HR, source-app attribution
    ("Demo Data · Samsung Health"), Refresh / Sync now actions
  - Last-7-days card: totals + best day + pure-Canvas steps bar chart
    (today's bar highlighted orange, empty days dashed)
  - Week data pipeline: local `PrefsDailySummaryCache` first → server
    `GET /api/v1/daily/range` when signed in → direct Health Connect read
    for days still missing (rows cached for next time)
  - Empty/offboarding hero: "Connect your watch" with Matchmaking CTA
  - "2h ago" style last-sync line from AuthStore
- Payload matches BE-C1: `{date, tz_offset, steps, sleep_seconds?, avg_hr?, source_apps[], source:"health_connect"}` — identity comes from the JWT (no `user` field)

## Build

```bash
./gradlew assembleDebug        # APK: app/build/outputs/apk/debug/app-debug.apk
./gradlew test                 # JVM unit tests (26: aggregation, payload, formatters, codec, cache)
./gradlew connectedDebugAndroidTest  # instrumented: dashboard UI states + permission-ok path
./gradlew build                # full build (lint + tests + assemble)
```

Requires JDK 17 and an Android SDK (`local.properties` → `sdk.dir`).

## Reproduce on an emulator (tester)

1. Start an API 34+ emulator with the **Health Connect** app installed
   (API 34+ includes the Health Connect controller; on older emulators install
   the Health Connect APK).
2. Install the data generator (writes mock steps/sleep/HR into Health Connect):
   `adb install app-data-gen.apk` — from the spike workspace
   (`boards/fitness-app/workspaces/t_22be008b/app-data-gen`). Grant write access.
3. Install this app: `adb install app/build/outputs/apk/debug/app-debug.apk`.
4. Backend up (BE-C1): `docker compose up` on the backend repo — API on
   `http://localhost:8000` (emulator reaches it at `http://10.0.2.2:8000`).
5. Open the app → Dashboard:
   - "Grant access in Health Connect" → allow Steps / Sleep / Heart rate.
   - "Connect your watch" → Health Connect matchmaking screen.
   - "Refresh" → today's steps/sleep/HR aggregate appears (sources listed).
6. Account tab → Register/Sign in (any email + ≥8 char password; base URL
   defaults to `http://10.0.2.2:8000/api/v1`).
7. "Sync now" → server logs the daily row (or `GET /api/v1/daily?date=YYYY-MM-DD`
   with the Bearer token).
8. FE-C2 dashboard checks:
   - Today card shows the real aggregate with source attribution
     (data generator writes `com.fitness.explorer.datagenerator` → "Demo Data").
   - "Last 7 days" strip totals + bar chart render; today's bar is orange.
   - Backend rows for prior days (if any) fill the strip after a signed-in refresh;
     with no backend and no HC grants, an empty/offboarding "Connect your watch"
     hero appears instead.
   - "Last sync: <date> (Xh ago)" appears under the cards after a successful sync.

## Layout

```
app/src/main/java/com/fitnessapp/android/
  FitnessApp.kt                 Application + manual DI container (dailyCache added)
  MainActivity.kt               Compose host
  data/
    HealthConnectRepository.kt  HC status, permissions, daily reads, matchmaking
    model/DailySummary.kt       domain model + aggregation (pure, unit-tested)
    model/DailySummaryCodec.kt  JSON codec for cache + BE-C1 GET responses (pure)
    model/DashboardFormatters.kt source labels, durations, relative time (pure)
    cache/DailySummaryCache.kt  SharedPreferences row cache + in-memory test double
    network/AuthStore.kt        JWT/email/base URL prefs (lastSync tracking)
    network/ApiClient.kt        OkHttp client (auth, postDaily, getDaily/range)
    sync/DailySyncWorker.kt     WorkManager worker (bg-permission aware)
    sync/SyncScheduler.kt       periodic + one-shot scheduling
  ui/
    MainScreen.kt               bottom nav: Dashboard / Challenges / Account
    dashboard/…                 DashboardScreen (stateless content), ViewModel,
                                WeekStepsChart (Canvas), DashboardUiState
    challenges/…                Phase 3 placeholder
    settings/…                  auth + base URL
```

## Notes / decisions

- Timezone: `DailySummary.date` is the device-local calendar date; `tz_offset`
  is minutes east of UTC at read time (BE-C1 validates ±14h).
- Sleep attribution: a session counts toward the local day it **ends** in
  (wake day), full duration clamped to 24h.
- `source_apps` = distinct Health Connect data origins (record metadata) for the day.
- Cleartext HTTP is scoped via `network_security_config.xml` to the dev loopback only
  (`10.0.2.2`, `localhost`, `127.0.0.1`) — everything else stays HTTPS-only.
  Production must use a real HTTPS endpoint.
- HC SDK 1.2.0-alpha05 is used because the Matchmaking API is only exposed there
  (`@OptIn(ExperimentalMatchmakingApi::class)`); the read path is unchanged from
  the validated 1.1.0 spike.
- Consent flow (SPIKE finding, enforced at API 36): the manifest MUST declare
  both the rationale activity (`androidx.health.ACTION_SHOW_PERMISSIONS_RATIONALE`)
  AND the `ViewPermissionUsageActivity` activity-alias
  (`VIEW_PERMISSION_USAGE` + `HEALTH_PERMISSIONS`, exported, protected by
  `START_VIEW_PERMISSION_USAGE`), or the Health Connect consent UI silently
  never opens.
- Background-read gate: the periodic worker skips the read when
  `READ_HEALTH_DATA_IN_BACKGROUND` is not granted (Android 15+). The one-shot
  "Sync now" path carries `trigger=foreground` and reads anyway — the app is on
  screen, so a foreground read is allowed. That is the card's documented fallback.
